package pong;

import static org.lwjgl.glfw.GLFW.*;

public class paddle{
	
	//Stores the dementions of the shape
	private float[] dem = {0.02f, 0.2f};
	//Stores its Cords
    private double[] coords = {-1f + dem[0], 0.0f};
    
    //Checks to see which key is pressed, so later on I can just pass on UI
    public void key_press (int key){
        if (key == GLFW_KEY_UP){
        		this.velX(main.max_vol);
        }
        else if (key == GLFW_KEY_DOWN){
        		this.velX(-main.max_vol);
        }
    }


    public double[] getCoords(){
        return coords;
    }
    
    public float[] getDem() {
    		return dem;
    }


    public void setCoords(double[] newValues){
        coords = newValues;
    }
    //Acts like velocity in that it will increment the position
    public void velY(double newValue){
        coords[1] = coords[1] + newValue;
    }
    public void velX(double newValue){
        coords[0] = coords[0] + newValue;
    }
}
